This is an example Python module.  Use the scripts as follows:

1) build.py - this will create to 
