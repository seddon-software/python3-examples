def f4():
    print "f4"
    