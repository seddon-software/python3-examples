from distutils.core import setup

setup(name='my-module',
      version='1.0',
      py_modules=['mymodule'],
      description='Example Module Distribution',
      long_description='shows how to install a module',
      license='there is no licence for this application',
      platforms='windows x86 x32',
      author='Chris Seddon',
      author_email='seddon-software@keme.co.uk',
      url='http://www.keme.net/~seddon-software',
      )
