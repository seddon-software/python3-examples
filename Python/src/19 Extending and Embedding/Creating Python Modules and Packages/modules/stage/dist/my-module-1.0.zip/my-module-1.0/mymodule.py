def f1():
    print "This is f1() in my Python module"

def f2():
    print "This is f2() in my Python module"

