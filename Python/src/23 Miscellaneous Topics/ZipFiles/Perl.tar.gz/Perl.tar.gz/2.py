import zipfile, zlib
import glob
import time

# note zlib is used for compression
fileName = "zips/Perl.zip"
theZip = zipfile.ZipFile(fileName, "r")


for file in glob.glob("zips/Perl/*"):
    indata = open(file, "rb").read()
    outdata = zlib.compress(indata, zlib.Z_BEST_COMPRESSION)

    print file, len(indata), "=>", len(outdata),
    print "%d%%" % (len(outdata) * 100 / len(indata))