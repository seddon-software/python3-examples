use point;

my $p1 = new point(3, 5);
$p1->moveBy(1,1);
my $p2 = new point(3, 5);
$p2->moveBy(-1,-1);
1
