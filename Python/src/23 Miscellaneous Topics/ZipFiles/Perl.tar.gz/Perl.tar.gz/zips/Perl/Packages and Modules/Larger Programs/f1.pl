sub f11
{
	print "f11 \n";	
}

sub f12
{
	print "f12 \n";
}

sub f13
{
	print "f13 \n";
}
