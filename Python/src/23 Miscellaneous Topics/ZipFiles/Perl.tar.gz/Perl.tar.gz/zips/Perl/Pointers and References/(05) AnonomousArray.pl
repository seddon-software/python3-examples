##################################################
#
#     array references
#
##################################################

# set up reference to an anonomous array
$arrayRef = ['Tom', 'Ali', 'Mary'];

# we can access the array using two different notations
# use $$ notation
print "$$arrayRef[0] \n";
print "$$arrayRef[1] \n";
print "$$arrayRef[2] \n";

print "---- \n";

# use -> notation
print "$arrayRef->[0] \n";
print "$arrayRef->[1] \n";
print "$arrayRef->[2] \n";

1