##########################################################
#
#	Test Packages
#
##########################################################

use lib './mylib';	# this module modifies @INC directly
print "@INC\n";

require "Routines.pl";

Func::Sub1();
Func::Sub2();
Func::Sub3();
Sub::Sub1();
Sub::Sub2();
Sub::Sub3();

1


