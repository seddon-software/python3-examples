##########################################################
#
#	String and Patterns
#
##########################################################



$text1 = "This line contains the number 8.73 and 4.67 \n";
$text2 = "This line does not contains any numbers \n";

$numberPattern = "\\d+\\.\\d+";
print $numberPattern;

if($text1 =~ $numberPattern) { print "Pattern found in text1 \n"; }
if($text2 !~ $numberPattern) { print "Pattern not found in text2 \n"; }

if($text1 ne "line") { print "String not found in text1 \n"; }
if($text2 ne "line") { print "String not found in text2 \n"; }
