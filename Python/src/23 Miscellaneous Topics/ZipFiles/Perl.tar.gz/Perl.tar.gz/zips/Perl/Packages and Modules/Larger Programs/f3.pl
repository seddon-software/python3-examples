sub f31
{
	print "f31 \n";	
}

sub f32
{
	print "f32 \n";
}

sub f33
{
	print "f33 \n";
}
