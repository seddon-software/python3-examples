##########################################################
#
#	Processing files a line at a time 
#
##########################################################

# assumes that script is called with -n option

print "$.   $_";
1