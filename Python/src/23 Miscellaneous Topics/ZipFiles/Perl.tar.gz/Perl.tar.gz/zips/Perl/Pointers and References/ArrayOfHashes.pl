##################################################
#
#     array of hash references
#
##################################################

$ref = [ { 'key1' => 11, 'key2' => 12, 'key3' => 13 },
         { 'key1' => 21, 'key2' => 22, 'key3' => 23 },
         { 'key1' => 31, 'key2' => 32, 'key3' => 33 } ];

print "$$ref[0]->{'key1'} \n";
print "$ref->[0]->{'key2'} \n";
print "$ref->[0]->{'key3'} \n";
print "$ref->[1]{'key1'} \n";
print "$ref->[1]{'key2'} \n";
print "$ref->[1]{'key3'} \n";
print "$ref->[2]{'key1'} \n";
print "$ref->[2]{'key2'} \n";
print "$ref->[2]{'key3'} \n";

1