##########################################################
#
#	Shift
#
##########################################################

@array = (1 .. 10);
print "@array \n";

shift @array;
print "@array \n";

shift @array;
print "@array \n";

shift @array;
print "@array \n";

shift @array;
print "@array \n";

1;
