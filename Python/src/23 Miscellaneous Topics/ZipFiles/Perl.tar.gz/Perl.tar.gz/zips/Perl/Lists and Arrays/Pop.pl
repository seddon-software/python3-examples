##########################################################
#
#	Pop
#
##########################################################

@array = (1 .. 10);
print "@array \n";

$n = pop(@array);
print "@array \n";

$n = pop(@array);
print "@array \n";

$n = pop(@array);
print "@array \n";

1;
