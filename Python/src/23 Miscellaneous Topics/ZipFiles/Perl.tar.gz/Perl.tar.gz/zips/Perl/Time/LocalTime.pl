##########################################################
#
#	localtime()
#
##########################################################



$theDate = localtime();
@theDate = localtime();
($sec, $min, $hour, $mday, $month, $year, 
             $wday, $yday, $isdst) = localtime();
print "SCALAR: $theDate \n";
print "ARRAY:  @theDate \n";

$month++;		# months start at Jan = 0
$year = $year + 1900;	# years start at 1900
print "sec:   $sec \n";
print "min:   $min \n";
print "hour:  $hour \n";
print "day:   $mday \n";
print "month: $month \n";
print "year:  $year \n";
