sub multiply {
  my ($a, $b) = @_;
  
  $temp = $a * $b;
  return $temp;
}


$a = 100;
$result = multiply(5, 3);

1
