##########################################################
#
#	Join
#
##########################################################

my @array = qw(This is the time for all good men);
my $text = join(":", @array);
print "$text \n";

1;
