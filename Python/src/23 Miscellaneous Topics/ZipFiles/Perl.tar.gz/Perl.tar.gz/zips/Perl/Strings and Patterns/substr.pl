##########################################################
#
#	substrings
#
##########################################################



$text = "Supercalifragalisticexpialidocious";

$subtext = substr($text, 9, 11);
print "$subtext \n";



1