import tarfile

fileName = "Perl.tar.gz"

tar = tarfile.open(fileName, "w:gz")
# tar.add("zips/Perl", arcname=fileName)
tar.add(".", arcname=fileName)
tar.close()